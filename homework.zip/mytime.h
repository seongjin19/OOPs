#pragma once
#include <iostream>

class CMytime
{
private:
	int m_hour;
	int m_min;
	int m_sec;
public:
	int getm_hour();
	void setm_hour(int hour);
	int getm_min();
	void setm_min(int min);
	int getm_sec();
	void setm_sec(int sec);
	void recalTime(int time);

};