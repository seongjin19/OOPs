#include "employee.h"

int CEmployee::getm_time()
{
	return m_time;
}

void CEmployee::setm_time(int time)
{
	m_time = time;
}

void CEmployee::inputData()
{
	int id;
	string name;
	string address;
	
	
	int time;

	cout << "Enter ID: ";
	cin >> id;

	cout << "Enter name: ";
	cin >> name;
	cin.ignore();

	cout << "Enter address: ";
	getline(cin, address);

	cout << "Enter work time(sec): ";
	cin >> time;

	setm_ID(id);
	setm_name(name);
	setm_address(address);
	setm_time(time);
	retime.recalTime(time);
	
}
void CEmployee::outputData()
{
	cout << "[" << getm_ID() << "] " << getm_name()<< "(" << setw(2) << setfill('0') << retime.getm_hour()<<":"<< setw(2) << setfill('0') <<retime.getm_min()<<":"<<setw(2)<<setfill('0')<<retime.getm_sec() << ")" << ", " << getm_address() << endl;
}