#pragma once
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

class Cperson
{
private:
	int m_ID;
	string m_name;
	string m_address;

public:
	int getm_ID();
	void setm_ID(int id);
	
	string getm_name();
	void setm_name(string name);
	
	string getm_address();
	void setm_address(string address);
	
	virtual void inputData();
	virtual void outputData();
};