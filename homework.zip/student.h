#pragma once
#include "person.h"

class Cstudent : public Cperson
{
private:
	float m_GPA;
public:
	float getm_GPA();
	void setm_GPA(float gpa);
	void inputData();
	void outputData();
};
