#include "person.h"
#include "student.h"
#include "employee.h"

int main(void)
{
//	// 1��
//	Cstudent student;
//
//	student.inputData();
//	student.outputData();
//
//	// 2��
//	CEmployee employee;
//	employee.inputData();
//	employee.outputData();
//
	//4��
	int count = 0;
	char key;
	Cperson **array = (Cperson**)malloc(sizeof(Cperson) * 1);
	
	while (true)
	{
		cout << "Enter a commend (q, s, e, p): ";
		cin >> key;
		if (key == 'q')
		{
			return 0;
		}
		else if (key == 's')
		{
			array[count] = new Cstudent();
			array[count]->inputData();
			realloc(array, sizeof(Cperson*)*(count+2));
			count++;
		}

		else if (key == 'e')
		{
			array[count] = new CEmployee();
			array[count]->inputData();
			realloc(array, sizeof(Cperson*)*(count+2));
			count++;
		}

		else if (key == 'p')
		{
			Cperson* test;
			for (int i = 0; i < count; i++)
			{
				for (int j = 0; j < count; j++)
				{
					if (array[i]->getm_ID() < array[j]->getm_ID())
					{
						test = array[i];
						array[i] = array[j];
						array[j] = test;
					}
				}
			}
			for (int i = 0; i < count; i++)
			{
				array[i]->outputData();
			}
		}
		
	}
	for (int i = 0; i < count; i++)
	{
		delete array[i];
	}
	free(array);

	return 0;
}