#include "person.h"

int Cperson::getm_ID()
{
	return m_ID;
}

void Cperson::setm_ID(int id)
{
	m_ID = id;
}

string Cperson::getm_name()
{
	return m_name;
}

void Cperson::setm_name(string name)
{
	m_name = name;
}

string Cperson::getm_address()
{
	return m_address;
}

void Cperson::setm_address(string address)
{
	m_address = address;
}

void Cperson::inputData()
{
	int id;
	string name;
	string address;
	
	cout << "Enter ID: ";
	cin >> id;

	cout << "Enter name: ";
	cin >> name;
	cin.ignore();

	cout << "Enter address: ";
	getline(cin, address);

	setm_ID(id);
	setm_name(name);
	setm_address(address);
}

void Cperson::outputData()
{
	cout << "[" << getm_ID() << "] " << getm_name() << ", " << getm_address() << endl;
	
}