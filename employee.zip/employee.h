#pragma once
#include "person.h"
#include "mytime.h"

class CEmployee :public Cperson
{
private:
	int m_time;
public:
	CMytime retime;

	int getm_time();
	void setm_time(int time);
	void inputData();
	void outputData();
};