#include "person.h"
#include "student.h"
#include "employee.h"

int main(void)
{
	// 1��
	Cstudent student;

	student.inputData();
	student.outputData();

	// 2��
	CEmployee employee;
	employee.inputData();
	employee.outputData();

	// 3��

	return 0;
}