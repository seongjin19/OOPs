#include "student.h"

float Cstudent::getm_GPA()
{
	return m_GPA;
}

void Cstudent::setm_GPA(float gpa)
{
	m_GPA = gpa;
}

void Cstudent::inputData()
{
	int id;
	string name;
	string address;
	float gpa;
	cout << "Enter ID: ";
	cin >> id;

	cout << "Enter name: ";
	cin >> name;
	cin.ignore();

	cout << "Enter address: ";
	getline(cin, address);

	cout << "Enter GPA: ";
	cin >> gpa;

	setm_ID(id);
	setm_name(name);
	setm_address(address);
	setm_GPA(gpa);
}
void Cstudent::outputData()
{
	cout << "[" << getm_ID() << "] " << getm_name() << "("<< getm_GPA() << ")" << ", " << getm_address() << endl;
}