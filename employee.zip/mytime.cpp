#include "mytime.h"

int CMytime::getm_hour()
{
	return m_hour;
}

void CMytime::setm_hour(int hour)
{
	m_hour = hour;
}

int CMytime::getm_min()
{
	return m_min;
}

void CMytime::setm_min(int min)
{
	m_min = min;
}

int CMytime::getm_sec()
{
	return m_sec;
}

void CMytime::setm_sec(int sec)
{
	m_sec = sec;
}

void CMytime::recalTime(int time)
{
	int save = time;
	int t[3];
	
	for (int i = 0; i < 3; i++)
	{
		t[i] = save % 60;
		save = save / 60;
	}
	m_hour = t[2];
	m_min = t[1];
	m_sec = t[0];
}